<?php
    require "../../vendor/autoload.php";
   // __DIR__ . "./../vendor/autoload.php";

    $composer = new Teste();

    echo $composer->imprimeNome();


