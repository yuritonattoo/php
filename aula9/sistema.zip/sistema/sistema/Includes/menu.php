<ul class="nav justify-content-center">
    <li class="nav-item">
        <a style="color:black;" class="nav-link active" href="index.php">HOME</a>
    </li>
    <li class="nav-item">
        <a style="color:black;" class="nav-link" href="cliente.php">CADASTRO CLIENTE</a>
    </li>
    <li class="nav-item">
        <a style="color:black;" class="nav-link" href="cadastroFornecedor.php">CADASTRO FORNECEDOR</a>
    </li>
    <li class="nav-item">
        <a style="color:black;" class="nav-link" href="cadastroUsuario.php">CADASTRO USUÁRIO</a>
    </li>
    <li class="nav-item">
        <a style="color:black;" class="nav-link" href="cadastroProduto.php">CADASTRO PRODUTO</a>
    </li>
    <li style="color:black;" class="nav-item dropdown">
            <a style="color:black;" class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            CADASTROS
            </a>
        <div style="color:black;" class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="pais.php">PAÍS</a>
            <a class="dropdown-item" href="estado.php">ESTADO</a>
            <a class="dropdown-item" href="cidade.php">CIDADE</a>
            <a class="dropdown-item" href="envioEmail.php">ENVIO DE EMAIL</a>
            <a class="dropdown-item" href="avaliacao.php">AVALIAÇÃO</a>
        </div>
    </li>
    <li class="nav-item">
        <a style="color:black;" class="nav-link" href="sair.php">SAIR</a>
    </li>
</ul>